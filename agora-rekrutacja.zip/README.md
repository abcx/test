# Agora s.a. :: Zadania testowe - frontend

1. Zainstaluj wymagane moduły **node.js**
2. Otwórz plik **main.js** i kieruj się komentarzami, które w nim znajdziesz
3. Otwórz plik **main.test.js** i napisz asercje, zgodnie ze wskazówkami zawartymi w tym pliku
4. Oczekiwany rezultat - po wpisaniu w konsoli `npm test` wszystkie testy będą "na zielono" ;)
5. Nie musisz wykonać wszystkich zadań testowych - zrób tyle ile możesz/potrafisz i odeślij do nas.